
// Agreed interface 
export interface IModelresultData {
    userId?: number;
    refDate: Date;
    bench1: number;
    bench2: number;
}

 