export interface IModelInput {
    retention: number;
    limit: number;
    exnum: number;
}
